DROP TABLE IF EXISTS analytics.events;
